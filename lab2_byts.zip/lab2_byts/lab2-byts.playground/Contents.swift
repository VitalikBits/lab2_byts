import Foundation

enum HouseType: String {
    case apartment = "Квартира"
    case detached = "Окремий будинок"
    case semiDetached = "Будинок на дві сім'ї"
}

struct House {
    var numberOfRooms: Int?
    var area: Double
    var hasPool: Bool?
    var type: HouseType
    var avArea: Double?{
        guard let rooms = numberOfRooms, rooms > 0 else {
            return nil
        }
        return area / Double(rooms)
    }
    func describe() {
        print("Тип будинку: \(type.rawValue)")
        print("Площа: \(area) м²")
        print("Середня площа: \(avArea) м²")
        // Optional Binding
        if let rooms = numberOfRooms {
            print("Кількість кімнат: \(rooms)")
        } else {
            print("Кількість кімнат: невідома")
        }

        if let pool = hasPool {
            if pool {
                print("Басейн: є")
            } else {
                print("Басейн: немає")
            }
        } else {
            print("Інформація про басейн відсутня")
        }
    }
}


func describeHouse(house: House) {
    print("----- Опис будинку -----")

    print("Тип: \(house.type.rawValue)")
    print("Площа: \(house.area) м²")

    let rooms = house.numberOfRooms ?? 0

    if rooms > 0 {
        print("Кількість кімнат: \(rooms)")
    } else {
        print("Кількість кімнат: невідома")
    }

    if let pool = house.hasPool {
        print("Басейн: \(pool ? "є" : "немає")")
    } else {
        print("Басейн: інформація відсутня")
    }

    print()
}

let house1 = House(
    numberOfRooms: 4,
    area: 120.5,
    hasPool: true,
    type: .detached
)

let house2 = House(
    numberOfRooms: 2,
    area: 65.0,
    hasPool: false,
    type: .apartment
)

let house3 = House(
    numberOfRooms: nil,
    area: 95.7,
    hasPool: nil,
    type: .semiDetached
)

let houses: [House] = [
    house1,
    house2,
    house3
]

for house in houses {
    describeHouse(house: house)
}


class Owner {
    var name: String
    var house: House

    init(name: String, house: House) {
        self.name = name
        self.house = house
    }

    func showHouseInfo() {
        print("===== Власник =====")
        print("Ім'я: \(name)")
        print("Інформація про будинок:")
        house.describe()
    }
}


let owner = Owner(
    name: "Олександр",
    house: house1
)

owner.showHouseInfo()
